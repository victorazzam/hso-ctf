#include <fcntl.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>

struct {
    char status[64];
    size_t cur_msg;
    struct {
        uint16_t size;
        char content[14];
    } messages[16];
    char *username;
} data;

void load_status(void);
void send_message(void);
void shred_message(void);
void print(const char *msg);
void wait(void);
uint8_t get_random(void);

int main(void) {
    load_status();
    for (size_t i = 0; i < sizeof data.messages / sizeof data.messages[0]; i++)
        data.messages[i].size = sizeof data.messages[i].content;
    data.username = calloc(1, 32);

    print("Enter your username: ");
    ssize_t r = read(STDIN_FILENO, data.username, 31);
    if (data.username[r - 1] == '\n')
        data.username[r - 1] = '\0';
    
    print("Access Granted.\nConnecting to remote server");
    wait();
    print("Connected.\nReceiving message from remote server");
    wait();
    print("What do you want to do?\n");
    
    while (1) {
        print("\nAvailable options:\n");
        
        print("1. Send message to remote server\n");
        
        print("2. Shred message\n");
        
        print("Choice: ");
        char choice[16];
        read(STDIN_FILENO, choice, sizeof choice);
        switch (choice[0]) {
            case '1':
                send_message();
                break;
            case '2':
                shred_message();
                break;
            default:
                print("Invalid choice!");
                break;
        }
    }
    return 0;
}

void send_message(void) {
    print("\n");
    
    print("Enter message: ");
    char msg[512];
    ssize_t r = read(STDIN_FILENO, msg, sizeof msg);
    if (r > data.messages[data.cur_msg].size)
        r = data.messages[data.cur_msg].size;

    memcpy(data.messages[data.cur_msg].content, msg, r);
    data.cur_msg = (data.cur_msg + 1) % (sizeof data.messages / sizeof data.messages[0]);

    print("Sending");
    wait();
    print("Response: \n");
    printf("We have received your message, %s. Thank you.\n", data.username);
}

void shred_message(void) {
    print("\n");

    print("Initiating shredding\n");

    print("Continue? (y/n) ");
    char resp[16];
    read(STDIN_FILENO, resp, sizeof resp);
    if (resp[0] != 'y')
        return;

    print("Shredding your messages\n");
    sleep(1);
    uint8_t index = get_random();
    uint8_t bit = get_random() & 8;
    ((uint8_t *)data.messages)[index] ^= 1 << bit;
}

void wait() {
    print(" ");
    sleep(1);
    print(".");
    sleep(1);
    print(".");
    sleep(1);
    print(".\n");
    sleep(1);
}

void load_status(void) {
    int fd = open("./flag.txt", 0);
    read(fd, data.status, sizeof data.status);
    close(fd);
}

void print(const char *msg) {
    write(STDOUT_FILENO, msg, strlen(msg));
}

uint8_t get_random(void) {
    int fd = open("/dev/urandom", 0);
    uint8_t random;
    read(fd, &random, sizeof random);
    close(fd);
    return random;
}
