Looks like some students think they know how to program in C.<br>
nc pwnable.ctf.hs-offenburg.de 20010

Binary can be found at [https://pwnable.ctf.hs-offenburg.de](https://pwnable.ctf.hs-offenburg.de)