Smashing the stack for fun and profit!<br>
nc pwnable.ctf.hs-offenburg.de 20000

Binary can be found at [https://pwnable.ctf.hs-offenburg.de](https://pwnable.ctf.hs-offenburg.de)<br>

Hint 1
------
Maybe you should read a little bit about tools and your environment setup. [Link](https://made0x78.com/bseries-env-setup/)