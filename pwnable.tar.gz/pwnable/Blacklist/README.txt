[Order ssh](http://pwnable.ctf.hs-offenburg.de:20014) credentials and get the flag!<br>

Hint 1
------
paths