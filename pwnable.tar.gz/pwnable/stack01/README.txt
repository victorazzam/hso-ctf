Smashing the stack for fun and profit!<br>
nc pwnable.ctf.hs-offenburg.de 20001

Binary can be found at [https://pwnable.ctf.hs-offenburg.de](https://pwnable.ctf.hs-offenburg.de)<br><br>

Hint 1
------
Just call win()<br>
A ["Beginner" Tutorial](https://made0x78.com/bseries-your-first-exploit/) could help.