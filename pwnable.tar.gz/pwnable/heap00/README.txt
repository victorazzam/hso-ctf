Use me if you can.<br>
nc pwnable.ctf.hs-offenburg.de 20011

Binary can be found at [https://pwnable.ctf.hs-offenburg.de](https://pwnable.ctf.hs-offenburg.de)