Smashing the stack for fun and profit!<br>This time you should take a cookie as long as they are there!<br> 
nc pwnable.hso-hacker.space 20005

Binary can be found at [https://pwnable.ctf.hs-offenburg.de](https://pwnable.ctf.hs-offenburg.de)<br>

Hint 1
------
A tutorial to follow along is available [here](https://made0x78.com/bseries-defeat-stack-cookies/).