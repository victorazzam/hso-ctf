A state of the art message storage service is now available. Try it :-)<br/>
nc pwnable.ctf.hs-offenburg.de 20016