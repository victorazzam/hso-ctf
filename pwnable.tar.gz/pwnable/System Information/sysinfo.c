#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct cmd_template {
    char username[16];
    char command[16];
} cmd_template;

struct cmd_template* cmd = NULL;

void create_cmd() {
    printf("Command created.");
    cmd = malloc(sizeof(cmd_template));
    strcpy(cmd->username, "root");
    strcpy(cmd->command, "uname -a");
}

void execute_cmd() {
    printf("Hello %s. I will execute your command %s\n", cmd->username, cmd->command);
    system(cmd->command);
}

void remove_cmd() {
    free(cmd);
}

void feedback() {
    char *feedback = malloc(32);
    fgets(feedback, 32, stdin);
    if (feedback[31] == '\n') {
        feedback[31] = '\0';
    }
    printf("Feedback received.");
}

void help() {
    puts("\n\n#####################");
    puts("[1] Create CMD");
    puts("[2] Execute CMD");
    puts("[3] Remove CMD");
    puts("[4] Feedback");
    puts("[5] Exit");
    puts("#####################");

    char choice;
    choice = getchar();
    getchar(); // remove newline
    switch (choice) {
        case '1':
            create_cmd();
            break;
        case '2':
            execute_cmd();
            break;
        case '3':
            remove_cmd();
            break;
        case '4':
            feedback();
            break;
        case '5':
            exit(0);
        default:
            puts("Nope. Command not found.");
            break;
    }    
}

int main(int argc, char **argv) {
	setbuf(stdout, NULL);
    setbuf(stderr, NULL);

    while(1) {
        help();
    }
}
