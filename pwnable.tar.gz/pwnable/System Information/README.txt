Simple remote command executer. Beta version supports only "uname -a".<br>
nc pwnable.ctf.hs-offenburg.de 20017