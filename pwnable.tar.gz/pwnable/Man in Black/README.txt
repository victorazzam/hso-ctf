Shopping is always nice. Have fun!<br>
nc pwnable.ctf.hs-offenburg.de 20012<br><br>

Binary can be found at [https://pwnable.ctf.hs-offenburg.de](https://pwnable.ctf.hs-offenburg.de)