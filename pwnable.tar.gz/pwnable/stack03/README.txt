Smashing the stack for fun and profit!<br>
nc pwnable.ctf.hs-offenburg.de 20003

Binary can be found at [https://pwnable.ctf.hs-offenburg.de](https://pwnable.ctf.hs-offenburg.de)<br>

Hint 1
------
A [Beginner Ret2Libc Tutorial](https://made0x78.com/bseries-ret2libc/) could help.